using System.Collections;
using System.Collections.Generic;
using UnityEngine;
// Include the namespace required to use Unity UI and Input System
using UnityEngine.InputSystem;

public class Player : MonoBehaviour {
	
	// Create public variables for player speed, and for the Text UI game objects
	public float speed = 3f;
    private float movementX;
    private float movementY;

	private Rigidbody rb;

	// At the start of the game..
	void Start ()
	{
		// Assign the Rigidbody component to our private rb variable
		rb = this.GetComponent<Rigidbody>();
		rb.freezeRotation = true;  //para o player não ficar rolando
	}

	void FixedUpdate ()
	{
		//Vector3 movement = new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical")); //InputManager
		Vector3 movement = new Vector3 (movementX, 0f, movementY).normalized; //InputSystem
		//rb.AddForce(movement * speed); //se quiser um movimento com aceleração e desaceleração
        rb.MovePosition(transform.position + movement * Time.deltaTime * speed);
	}

    void OnMove(InputValue value)
    {
        Vector2 v = value.Get<Vector2>();

		movementX = v.x;
		movementY = v.y;
    }

	
	void OnTriggerEnter(Collider other) 
	{

	}
}