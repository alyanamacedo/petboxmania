using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlataformCreator : MonoBehaviour
{
    public GameObject cubePrefab;
    public Vector3 startPosition;
    public int rows = 5; //eixo Z
    public int cols = 8; // eixo X
    private float offsetZ, offsetX = 0f;

    void Start()
    {
        if(rows%2 == 0) offsetZ = 0.5f;
        if(cols%2 == 0) offsetX = 0.5f;

        for (int i = 0; i < rows; i++)
        {
            for (int j = -(cols/2); j < cols/2; j++)
            {
                Vector3 cubePosition = startPosition + new Vector3(j+offsetX, 0.0f, i+offsetZ);
                GameObject cube = Instantiate(cubePrefab, cubePosition, Quaternion.identity);
                cube.transform.SetParent(transform);
                // Randomize the cube's starting position
                Vector3 randomOffset = new Vector3(Random.Range(-100f, 100f), Random.Range(-100f, 100f), Random.Range(-100f, 100f));
                cube.transform.position += randomOffset;
                // Apply a coroutine to move the cube towards the target position over time
                StartCoroutine(MoveToPosition(cube, cubePosition, Random.Range(0f, 2f)));
            }
        }
    }

    IEnumerator MoveToPosition(GameObject cube, Vector3 targetPosition, float duration)
    {
        float elapsedTime = 0.0f;

        Vector3 startingPosition = cube.transform.position;

        while (elapsedTime < duration)
        {
            elapsedTime += Time.deltaTime;
            float t = Mathf.Clamp01(elapsedTime / duration); // Calculate the percentage of the movement completed
            // Use a smooth step function to move the cube towards the target position
            cube.transform.position = Vector3.Lerp(startingPosition, targetPosition, Mathf.SmoothStep(0.0f, 1.0f, t));
            yield return null; // Wait for the next frame
        }

        cube.transform.position = targetPosition; // Ensure the cube reaches the exact target position
    }
}
