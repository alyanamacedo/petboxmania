using System.Collections;
using System.Collections.Generic;
using UnityEngine;
// Include the namespace required to use Unity UI and Input System
using UnityEngine.InputSystem;

public class Player : MonoBehaviour {
	
	// Create public variables for player speed, and for the Text UI game objects
	public float speed = 3f;
    private float movementX, movementY;
	public float rotationAngle = 5f; // Ângulo de inclinação do cubo

	//private InputAction movePlayer1, movePlayer2;
    //private Rigidbody rbPlayer1, rbPlayer2;

	private Rigidbody rb;

	public bool isStarting = true; //Quando inicia jogo
	public bool isFalling = false; // Indica se o jogador está caindo
    public float fallTime = 0f; // Contador de tempo de queda

	//Awake gets called first since the GameObject was active, then Start, then FixedUpdate (same frequency as the physics system), Update (every frame), and finally LateUpdate (after (every frame)
	void Start ()
	{
		//movePlayer1.Enable();
		//movePlayer2.Enable();
		
		rb = this.GetComponent<Rigidbody>();
		rb.freezeRotation = true;  //para o player não ficar rolando
		rb.useGravity = false;
		transform.position = new Vector3(transform.position.x, 8.5f, transform.position.z);
		StartCoroutine(IsStarting());
	}

	void FixedUpdate ()
	{
		//Vector3 movement = new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical")); //InputManager
		Vector3 movement = new Vector3 (movementX, 0f, movementY).normalized; //InputSystem
		//rb.AddForce(movement * speed); //se quiser um movimento com aceleração e desaceleração
        rb.MovePosition(transform.position + movement * Time.deltaTime * speed);

        // Calcula a rotação do cubo para incliná-lo e aplica
        Quaternion tiltRotation = Quaternion.Euler(-movementY * rotationAngle, 0f, movementX * rotationAngle);
        rb.MoveRotation(tiltRotation);
	}

	void Update() {
        // Verifica se o jogador está caindo
        if (transform.position.y < -1f && !isFalling) {
            isFalling = true;
            fallTime = 0f;
        }

        // Se o jogador estiver caindo
        if (isFalling) {
            transform.Rotate(new Vector3(1,1,1), 150f * Time.deltaTime); // Rotaciona o jogador
            fallTime += Time.deltaTime;
            // Se passaram mais de x segundos, destrói o jogador
            if (fallTime > 1f) Destroy(gameObject);
        }
    }

    void OnMove(InputValue value)
    {
        Vector2 v = value.Get<Vector2>();

		movementX = v.x;
		movementY = v.y;
    }
	
	void OnTriggerEnter(Collider other) 
	{
		// ..and if the GameObject you intersect has the tag 'Pick Up' assigned to it..
		if (other.gameObject.CompareTag ("Ground"))
		{
			//other.gameObject.SetActive (false);
			Debug.Log("");
		}
	}

	IEnumerator IsStarting()
    {
        yield return new WaitForSeconds(2);
		rb.useGravity = true;
		isStarting = false;
    }
}