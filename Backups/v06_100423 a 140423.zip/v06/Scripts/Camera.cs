using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camera : MonoBehaviour
{
    public Player player;
    private Transform target; // Referência para o transform do jogador
    private bool changeTarget = false;
    public Transform target_backup; //Para quando o player cair, ter um segundo ponto focal
    public float smoothTime = 0.3f; // Tempo de suavização
    private Vector3 offset; //distância do target
    private Vector3 velocity = Vector3.zero; // Velocidade atual

    // Start is called before the first frame update
    private void Start()
    {
        //target_backup.GetComponent<MeshRenderer>().enabled = false;
        if(player.isStarting){
            target = target_backup;
        }else{
            target = player.transform;
        }
        //Define a distância da posição de destino da câmera com base na posição do jogador
        offset = transform.position - target.position;
    }

    private void Update() {
        //muda o target depois que o player cai da plataforma
        if(!changeTarget && player.fallTime > 1f){
            changeTarget = true;
            target = target_backup;
        }
    }

    // LateUpdate é chamado a cada frame mas também depois de todas as atualizações serem feitas
    private void LateUpdate()
    {
        // Suaviza o movimento da câmera para a posição de destino
        transform.position = Vector3.SmoothDamp(transform.position, target.position + offset, ref velocity, smoothTime);

        // Verifica se o jogador está parado e aplica uma desaceleração suave
        if (target.GetComponent<Rigidbody>() && target.GetComponent<Rigidbody>().velocity.magnitude <= 0.1f) {
            smoothTime = 0.6f; // Define um tempo de suavização maior
        } else {
            smoothTime = 0.3f; // Retorna ao tempo de suavização normal
        }
    }
}