using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerManager : MonoBehaviour
{
    public List<Player> players;
    public List<InputActionAsset> assetPlayer; //Hierarquia: InputActionAsset -> InputActionMap -> InputAction
    private List<(int,List<InputAction>)> actionPlayer;

    // Start is called before the first frame update
    void Start()
    {
        actionPlayer = new List<(int,List<InputAction>)>();
        for(int i=0; i<players.Count; i++){
            players[i].idPlayer = i;
            InputActionMap actionMap = assetPlayer[i].FindActionMap("Player"); // Busca o ActionMap pelo nome
            List<InputAction> actions = new List<InputAction>();
            int j = 0;
            foreach (InputAction action in actionMap.actions){
                MethodInfo methodInfo = this.GetType().GetMethod(action.name, BindingFlags.NonPublic | BindingFlags.Instance);
                actions.Add(actionMap.FindAction(action.name)); // Procura o InputAction de movimentação pelo nome
                actions[j].performed += (context) => methodInfo.Invoke(this, new object[] { context });
                actions[j].Enable();
                j++;
            }
            actionPlayer.Add((i, actions)); //i = id do player, actions é a lista de actions do player
        }
   
        /*foreach (var tuple in actionPlayer){
            Debug.Log($"ID: {tuple.Item1}");
            foreach (var action in tuple.Item2){
                Debug.Log($"Action Name: {action.name}");
            }
        }*/
    }

    private void Move(InputAction.CallbackContext context) 
    {
        /*
        for(int i=0; i<players.Count; i++){
            players[i].OnMove(context);
        }
        */
        
        Vector2 moveValue = context.ReadValue<Vector2>(); // Obtém o valor de entrada do dispositivo
        string commandName = context.action.name; // Obtém o nome do comando pressionado
        string deviceName = context.control.device.name; // Obtém o nome do dispositivo utilizado
        Debug.Log("Command " + commandName + " used on device " + deviceName + " with value " + moveValue); // Imprime no console
        
    }

    private void Shake(InputAction.CallbackContext context){
        Debug.Log("Manager SHAKE");
    }

    void FixedUpdate()
    {
        /*PAREI AQUI
            actionPlayer contém a lista com todos os players e suas respectivas actions. No start já está conseguindo linkar as actions com os respectivos métodos, então os métodos Move e Shake está funcionando. O que falta é a partir daí chamar o método correspondente na classe Player.
            Alguns métodos serão chamados dessa forma, mas o Move precisa ser chamado por aqui para que o movimento seja fluído.
            (CORREÇÃO A FAZER AQUI) precisa atualizar o actionPlayer[i] para que leia a action correspondente, pois antes era: 
                    private List<InputAction> actionPlayer;
            e agora é:
                    private List<(int,List<InputAction>)> actionPlayer;
        */

        /*
        for(int i=0; i<players.Count; i++){
            if(players[i]){
                Debug.Log("Move player "+i+": "+actionPlayer[i].ReadValue<Vector2>());

                Vector2 moveInput = actionPlayer[i].ReadValue<Vector2>();
                players[i].OnMove(moveInput);
            }
        }
        */
    }

    void Update() {
        /*
        for(int i=0; i<players.Count; i++){
            players[i].IsFalling();
        }
        */
    }
}
