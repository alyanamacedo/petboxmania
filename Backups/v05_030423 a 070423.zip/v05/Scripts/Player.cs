using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class Player : MonoBehaviour {
	
	[Tooltip("idPlayer: 0-gato vermelho; 1-cachorro azul; 2-????; 3-???")]
	[HideInInspector]
	public int idPlayer;

	// Create public variables for player speed, and for the Text UI game objects
	public float speed = 3f;
    private float movementX, movementY;
	public float rotationAngle = 10f; // Ângulo de inclinação do cubo
	private Rigidbody rb;

	public bool isStarting = true; //Quando inicia jogo
	public bool isFalling = false; // Indica se o jogador está caindo
    public float fallTime = 0f; // Contador de tempo de queda

	void Start ()
	{
		rb = this.GetComponent<Rigidbody>();
		rb.freezeRotation = true;  //para o player não ficar rolando
		rb.useGravity = false;
		transform.position = new Vector3(transform.position.x, 8.5f, transform.position.z);
		StartCoroutine(IsStarting());
	}

	public void OnMove(Vector2 moveInput)
    {
		Vector3 movement = new Vector3(moveInput.x, 0f, moveInput.y).normalized; //InputSystem
		//rb.AddForce(movement * speed); //se quiser um movimento com aceleração e desaceleração
        rb.MovePosition(transform.position + movement * Time.deltaTime * speed);

        // Calcula a rotação do cubo para incliná-lo e aplica
        Quaternion tiltRotation = Quaternion.Euler(-moveInput.y * rotationAngle, 0f, moveInput.x * rotationAngle);
        rb.MoveRotation(tiltRotation);
    }

/*
	public void OnMove(InputAction.CallbackContext context)
    {
		Vector2 moveInput = context.ReadValue<Vector2>();
		Vector3 movement = new Vector3(moveInput.x, 0f, moveInput.y).normalized; //InputSystem
		//rb.AddForce(movement * speed); //se quiser um movimento com aceleração e desaceleração
        rb.MovePosition(transform.position + movement * Time.deltaTime * speed);

        // Calcula a rotação do cubo para incliná-lo e aplica
        Quaternion tiltRotation = Quaternion.Euler(-moveInput.y * rotationAngle, 0f, moveInput.x * rotationAngle);
        rb.MoveRotation(tiltRotation);
	}*/

/*
	public void OnShake(InputValue inputValue){
		Debug.Log("SHAKE "+idPlayer);
	}
*/
	public void IsFalling() {
        // Verifica se o jogador está caindo
        if (transform.position.y < 1f && !isFalling) {
            isFalling = true;
            fallTime = 0f;
        }
        if (isFalling) {
            transform.Rotate(new Vector3(1,1,1), 150f * Time.deltaTime); // Rotaciona o jogador
            fallTime += Time.deltaTime;
            if (fallTime > 1f) Destroy(gameObject); // Se passaram mais de x segundos, destrói o jogador
        }
    }
	
	void OnTriggerEnter(Collider collision) 
	{
		if (idPlayer == 0 && collision.gameObject.CompareTag ("TargetRed"))
		{
			Debug.Log("GATO conseguiu encostar no VERMELHO ---- "+collision.gameObject.name);
		}
		if (idPlayer == 1 && collision.gameObject.CompareTag ("TargetBlue"))
		{
			Debug.Log("CAHORRO conseguiu encostar no AZUL ---- "+collision.gameObject.name);
		}
	}

	IEnumerator IsStarting()
    {
        yield return new WaitForSeconds(2);
		rb.useGravity = true;
		isStarting = false;
    }
}