using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerManager : MonoBehaviour
{
    public float speed = 5f;
    public float rotationAngle = 5f; // Ângulo de inclinação do cubo
    private bool isStarting = true; //Quando inicia jogo
	private bool isFallingP1, isFallingP2; // Indica se o jogador está caindo
    private float fallTimeP1, fallTimeP2; // Contador de tempo de queda
    public GameObject player1, player2;
    public InputAction movePlayer1, movePlayer2;
    private Rigidbody rbPlayer1, rbPlayer2;

    // Start is called before the first frame update
    void Start()
    {
        isFallingP1 = isFallingP2 = false;
        fallTimeP1 = fallTimeP2 = 0f;

        rbPlayer1 = player1.GetComponent<Rigidbody>();
        rbPlayer2 = player2.GetComponent<Rigidbody>();
        // Enable the input actions for both players
        movePlayer1.Enable();
        movePlayer2.Enable();

		rbPlayer1.freezeRotation = true;  //para o player não ficar rolando
		rbPlayer1.useGravity = false;
		player1.transform.position = new Vector3(player1.transform.position.x, 8.5f, player1.transform.position.z);
		StartCoroutine(IsStarting(rbPlayer1));

        rbPlayer2.freezeRotation = true;  //para o player não ficar rolando
		rbPlayer2.useGravity = false;
		player2.transform.position = new Vector3(player2.transform.position.x, 8.5f, player2.transform.position.z);
		StartCoroutine(IsStarting(rbPlayer2));
    }

    void FixedUpdate()
    {
        // Move player 1
        if(player1){
            Vector2 moveInput1 = movePlayer1.ReadValue<Vector2>();
            Vector3 moveDirection1 = new Vector3(moveInput1.x, 0f, moveInput1.y).normalized;
            rbPlayer1.MovePosition(player1.transform.position + moveDirection1 * speed * Time.fixedDeltaTime);
            // Calcula a rotação do cubo para incliná-lo e aplica
            Quaternion tiltRotation1 = Quaternion.Euler(-moveInput1.y * rotationAngle, 0f, moveInput1.x * rotationAngle);
            rbPlayer1.MoveRotation(tiltRotation1);
        }
        // Move player 2
        if(player2){
            Vector2 moveInput2 = movePlayer2.ReadValue<Vector2>();
            Vector3 moveDirection2 = new Vector3(moveInput2.x, 0f, moveInput2.y).normalized;
            rbPlayer2.MovePosition(player2.transform.position + moveDirection2 * speed * Time.fixedDeltaTime);
            // Calcula a rotação do cubo para incliná-lo e aplica
            Quaternion tiltRotation2 = Quaternion.Euler(-moveInput2.y * rotationAngle, 0f, moveInput2.x * rotationAngle);
            rbPlayer2.MoveRotation(tiltRotation2);
        }
    }

    void Update() {
        // Verifica se o jogador está caindo
        if (player1 && player1.transform.position.y < 1f && !isFallingP1) {
            isFallingP1 = true;
            fallTimeP1 = 0f;
        }
        if (player2 && player2.transform.position.y < 1f && !isFallingP2) {
            isFallingP2 = true;
            fallTimeP2 = 0f;
        }

        // Se o jogador estiver caindo
        if (player1 && isFallingP1) {
            player1.transform.Rotate(new Vector3(1,1,1), 150f * Time.deltaTime); // Rotaciona o jogador
            fallTimeP1 += Time.deltaTime;
            // Se passaram mais de x segundos, destrói o jogador
            if (fallTimeP1 > 1f) Destroy(player1);
        }
        if (player2 && isFallingP2) {
            player2.transform.Rotate(new Vector3(1,1,1), 150f * Time.deltaTime); // Rotaciona o jogador
            fallTimeP2 += Time.deltaTime;
            // Se passaram mais de x segundos, destrói o jogador
            if (fallTimeP2 > 1f) Destroy(player2);
        }
    }

    void OnTriggerEnter(Collider collision) 
	{
		// ..and if the GameObject you intersect has the tag 'Pick Up' assigned to it..
		if (collision.gameObject.CompareTag ("TargetBlue"))
		{
			//other.gameObject.SetActive (false);
			Debug.Log("Conseguiu "+collision.gameObject.name);
		}
	}

    IEnumerator IsStarting(Rigidbody rb)
    {
        yield return new WaitForSeconds(2);
		rb.useGravity = true;
		isStarting = false;
    }
}
